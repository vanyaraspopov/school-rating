<?php
class srActivitySection extends xPDOSimpleObject {}