<?php

$_lang['area_schoolrating_main'] = 'Main';

$_lang['setting_schoolrating_some_setting'] = 'Some setting';
$_lang['setting_schoolrating_some_setting_desc'] = 'This is description for some setting';