<?php
class srActivityCoefficient extends xPDOSimpleObject {}