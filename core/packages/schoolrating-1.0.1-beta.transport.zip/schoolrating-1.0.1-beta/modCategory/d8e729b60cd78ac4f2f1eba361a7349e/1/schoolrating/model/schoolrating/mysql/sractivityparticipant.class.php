<?php
require_once (dirname(dirname(__FILE__)) . '/sractivityparticipant.class.php');
class srActivityParticipant_mysql extends srActivityParticipant {}