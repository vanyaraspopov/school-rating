<?php
class srActivity extends xPDOSimpleObject {}