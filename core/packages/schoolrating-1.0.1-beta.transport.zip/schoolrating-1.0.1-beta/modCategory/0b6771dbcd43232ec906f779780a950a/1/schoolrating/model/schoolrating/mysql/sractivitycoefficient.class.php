<?php
require_once (dirname(dirname(__FILE__)) . '/sractivitycoefficient.class.php');
class srActivityCoefficient_mysql extends srActivityCoefficient {}