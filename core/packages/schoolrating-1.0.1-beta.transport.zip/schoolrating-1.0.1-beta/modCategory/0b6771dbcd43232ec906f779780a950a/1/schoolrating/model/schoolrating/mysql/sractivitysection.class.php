<?php
require_once (dirname(dirname(__FILE__)) . '/sractivitysection.class.php');
class srActivitySection_mysql extends srActivitySection {}