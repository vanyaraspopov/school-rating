<?php
require_once (dirname(dirname(__FILE__)) . '/sractivity.class.php');
class srActivity_mysql extends srActivity {}