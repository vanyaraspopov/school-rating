<?php
class srActivityParticipant extends xPDOSimpleObject {}