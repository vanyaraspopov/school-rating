<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'srActivitySection',
    1 => 'srActivityCoefficient',
    2 => 'srActivity',
    3 => 'srActivityParticipant',
  ),
);